# LegalEase Command Center vNext — Immediate Next Steps

## 1. Add the approved inputs to the repository

From the repository root, place the files at these exact paths:

```text
LEGALEASE_COMMAND_CENTER_MASTER_BUILD_PLAN_CODEX.md
assets/brand/logos/legalease-logo-white-2025.png
docs/ux-vnext/reference/command-center-vnext-approved-direction.png
```

Use the revised master plan. Do not commit the older v1.0 plan under the governing filename.

The white logo file is the production asset for the navy Command Center sidebar. The visual-reference image is a directional design reference. Neither file should be recreated by Codex.

## 2. Commit the inputs before asking Codex to build

Recommended commit:

```bash
git checkout main
git pull --ff-only
git checkout -b codex/ccx-vnext-inputs
mkdir -p assets/brand/logos docs/ux-vnext/reference
# Copy the three supplied files into their paths.
git add LEGALEASE_COMMAND_CENTER_MASTER_BUILD_PLAN_CODEX.md \
  assets/brand/logos/legalease-logo-white-2025.png \
  docs/ux-vnext/reference/command-center-vnext-approved-direction.png
git commit -m "docs(ux-vnext): add master plan and approved brand references"
git push -u origin codex/ccx-vnext-inputs
```

Merge this small inputs-only change before CCX-000, or have Codex work from the branch containing it.

## 3. Run CCX-000 first

Paste `CODEX_START_PROMPT_CCX_000_REVISED.txt` into Codex.

CCX-000 is deliberately verification-only. It should not redesign the interface. Its purpose is to establish the current SHA, tests, routes, feature flags, payload sizes, safety posture, and approved-asset checksums so later work can be distinguished from pre-existing defects.

Review the CCX-000 PR carefully. Merge only when:

- The baseline is reproducible.
- Existing failures are clearly identified.
- No user-facing behavior changed.
- The approved logo and visual reference were verified, not modified.
- Codex states that CCX-001 is unblocked.

## 4. Execute one packet per pull request

Use `CODEX_FOLLOW_ON_PROMPT_TEMPLATE.txt`, replacing the packet number and title.

Recommended order:

```text
CCX-001  Route and capability inventory
CCX-002  Founder-language registry
CCX-003  vNext feature flag and shell boundary
CCX-004  Shared UI primitives
CCX-005  Browser-level test infrastructure
CCX-006  Approved LegalEase design system
CCX-100  Desktop five-destination shell
CCX-101  Responsive shell
```

Do not ask Codex to “build the whole plan” in one run. The repository is large and safety-sensitive; one focused PR at a time is the control mechanism.

## 5. First visual approval checkpoint

After CCX-006, review the token/component showcase. It must show:

- Deep navy sidebar
- Exact all-white LegalEase logo
- Soft light teal selected navigation
- LegalEase orange `#F04800` for the primary action
- Warm-white/light-gray work surfaces
- Neutral secondary actions
- Distinct success, warning, and danger states

After CCX-100 and CCX-101, review desktop, laptop, tablet, and mobile screenshots before continuing. Reject any unofficial logo, black sidebar, neon teal, overuse of orange, or static mockup-only page.

## 6. Functional release checkpoints

The build becomes useful in controlled increments:

- **Phase 1:** Navigation and shell are usable behind a feature flag.
- **Phase 2:** Today and Inbox direct Roger to real work.
- **Phase 3:** Social works from idea through review and scheduling/publishing readiness.
- **Phase 4:** Outreach works from audience through review, approval, launch, and monitoring.
- **Phase 5:** Partner records expose relationship status, history, files, outreach, and next action.
- **Phase 6:** Files and Investor Room support real upload, preview, organization, readiness, and access control.
- **Phase 7–8:** Onboarding, accessibility, performance, production verification, and legacy cleanup make vNext the default.

A page is not complete because it resembles the mockup. It must use real data, persist actions, survive reload, handle errors and permissions, and pass its end-to-end tests.

## 7. Keep external actions safe during the build

Until the relevant packet and acceptance suite explicitly pass:

- Keep live social-publishing gates off.
- Keep live email sending off except in an approved test fixture.
- Do not weaken suppression, unsubscribe, hold, approval, role, or audit behavior.
- Do not allow a browser flag to grant sending or publishing authority.
- Do not merge a packet with a known duplicate-action or authorization defect.

## 8. Recommended founder review rhythm

At each user-visible PR, ask Codex to provide:

1. Before/after screenshots
2. The exact workflow to test manually
3. The real data source behind each displayed metric
4. The empty, loading, error, blocked, and success states
5. Tests run and results
6. What remains intentionally out of scope
7. The feature flag or rollback path

Approve the experience based on whether a first-time user knows what to do next—not on the number of features shown.
